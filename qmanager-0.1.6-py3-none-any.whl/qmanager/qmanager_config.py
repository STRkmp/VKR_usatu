from pydantic import BaseSettings, Extra
from typing import Optional


class QManagerSettings(BaseSettings, extra=Extra.allow):
    queue_type: str
    host: Optional[str]
    port: Optional[int]
    virtual_host: Optional[str]
    exchange: Optional[str]
    username: Optional[str]
    password: Optional[str]
    queue_timeout: int = 10
    queue_in: str
    queue_out: Optional[str]
    queue_err: Optional[str]
    auto_ack: Optional[bool] = True
