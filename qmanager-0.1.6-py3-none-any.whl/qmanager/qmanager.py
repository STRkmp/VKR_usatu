from abc import ABC, abstractmethod     # подключаем инструменты для создания абстрактных классов
from pydantic import BaseSettings
from typing import Callable, Optional
from threading import Event
import logging
import logging.config
from logging import Logger
try:
    import concurrent_log_handler
except:
    pass


class QueueManager(ABC):

    logger = None
    _stop_event = Event()

    def __init__(self, settings: BaseSettings, callback_func: Callable = None, on_error_callback_func: Callable = None):
        QueueManager.logger = QueueManager.configure_logger()
        self.logger.info(f'{type(self).__name__}: Initialization.')
        self.settings = settings
        self.queue_in = settings.queue_in
        self.queue_out = settings.queue_out
        self.queue_err = settings.queue_err
        self.callback = self.default_callback
        self.on_error_callback = self.default_on_error_callback
        if callback_func is not None:
            self.callback = callback_func
        elif self.queue_out is None:
            self.callback = self.none_callback
        if on_error_callback_func is not None:
            self.on_error_callback = on_error_callback_func
        elif self.queue_err is None:
            self.on_error_callback = self.none_callback
        self._run = True

    @classmethod
    def configure_logger(cls, logger_name: str = 'qmanager', log_level=logging.ERROR) -> Logger:
        """ Инициализация логгера """
        try:
            logging.config.fileConfig('logger.ini')
            return logging.getLogger(logger_name)
        except:
            app_logger = logging.getLogger(logger_name)
            app_logger.setLevel(log_level)
            handler = logging.FileHandler(f'{logger_name}.log')
            handler.setLevel(log_level)
            handler.setFormatter(logging.Formatter('%(asctime)s %(module)s: %(message)s'))
            app_logger.addHandler(handler)
            return app_logger

    @classmethod
    def set_stop_event(cls, event: Event) -> None:
        cls._stop_event = event

    @classmethod
    def is_stopped(cls) -> bool:
        return cls._stop_event.is_set()

    @classmethod
    def stop_all(cls) -> None:
        cls._stop_event.set()

    def is_running(self) -> bool:
        return self._run

    def stop_sighandler(self, signum, frame) -> None:
        self.stop()

    def stop(self) -> None:
        self.logger.info(f'{type(self).__name__}: STOP signal received.')
        self._run = False

    @abstractmethod
    def init_queues(self) -> bool:
        pass

    @abstractmethod
    def publish(self, data: bytes, queue_name: str = None, headers: dict = None) -> bool:
        pass

    @abstractmethod
    def consume(self, queue_name: str = None) -> None:
        pass

    def default_callback(self, data: bytes, headers: dict = None) -> None:
        self.publish(data=data, queue_name=self.queue_out, headers=headers)

    def default_on_error_callback(self, data: bytes, headers: dict = None) -> None:
        self.publish(data=data, queue_name=self.queue_err, headers=headers)

    def none_callback(self, data: bytes, headers: dict = None) -> None:
        pass
