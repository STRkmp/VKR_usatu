from ..qmanager import QueueManager
from pydantic import BaseSettings
from typing import Callable, Optional
from kombu import Connection, Exchange, Consumer, Producer, Queue, Message
#from kombu.transport.redis import Channel
from kombu.utils.compat import nested
import uuid
import time
import socket
import traceback


class KombuRedisQueueManager(QueueManager):
    """ Kombu Redis Queue Manager """
    def __init__(self, settings: BaseSettings, callback_func: Callable = None, auto_ack: bool = True,
                 auto_declare: bool = True):
        QueueManager.__init__(self, settings, callback_func)
        self._auto_ack = auto_ack
        self._auto_declare = auto_declare
        self._connection_url = f'redis://{self.settings.username}:{self.settings.password}@' \
                               f'{self.settings.host}:{self.settings.port}/0'
        self._connection = self.get_connection()
        self._exchange = Exchange(self.settings.exchange, type='direct', durable=True)
        self.init_queues()

    def get_connection(self) -> Optional[Connection]:
        try:
            connection = Connection(self._connection_url)
            self.logger.info(f"Connecting to Redis Server")
            return connection
        except Exception as error:
            self.logger.error(f"Can't get connection to Redis Server: {traceback.format_exc()}")
        return None

    def init_queues(self) -> None:
        if self._auto_declare:
            if self.settings.queue_in is not None:
                self._init_queue(self.settings.queue_in)
            if self.settings.queue_err is not None:
                self._init_queue(self.settings.queue_err)
            if self.settings.queue_out is not None:
                self._init_queue(self.settings.queue_out)

    def _init_queue(self, queue_name: str) -> Optional[Queue]:
        try:
            self.logger.info(f"Initializing Queue {queue_name}...")
            with self._connection.channel() as channel:
                queue = Queue(queue_name, exchange=self._exchange, routing_key=queue_name)
                queue.declare(channel=channel)
            return queue
        except Exception as ex:
            self.logger.info(f'{ex}')
        return None

    def publish(self, data: bytes, queue_name: str = None, headers: dict = None) -> bool:
        if queue_name is None:
            queue_name = self.settings.queue_in
        if headers is None:
            headers = {'businessId': str(uuid.uuid4())}
        try:
            with self._connection.channel() as channel:
                producer = Producer(channel)
                self.logger.debug(f'Publishing message in {queue_name}. '
                                  f'Header businessId: {headers.get("businessId")}')
                producer.publish(
                    body=data,                      # message to send
                    exchange=self._exchange,        # destination exchange
                    routing_key=queue_name,              # destination routing key
                    content_type='application/octet-stream',
                    headers=headers,
                    retry=True,
                    retry_policy={
                        'interval_start': self.settings.queue_timeout,    # First retry timeout,
                        'interval_step': 0,     # then increase by n sec for every retry.
                        'interval_max': self.settings.queue_timeout,     # but don't exceed <int> sec. between retries.
                        'max_retries': 3,       # give up after n tries.
                    }
                )
            return True
        except Exception as error:
            self.logger.error(f'Error while publishing message: {error}')
            time.sleep(self.settings.queue_timeout)
        return False

    def consume(self, queue_name: str = None) -> None:
        if queue_name is None:
            queue_name = self.settings.queue_in
        queue = Queue(queue_name, exchange=self._exchange, routing_key=queue_name)
        while self._run and not self.is_stopped():
            try:
                if self._connection is None:
                    self._connection = self.get_connection()
                with self._connection.channel() as channel:
                    with Consumer(channel=channel, queues=[queue], callbacks=[self.on_message_received_callback],
                                  auto_declare=True, no_ack=self._auto_ack, prefetch_count=1) as consumer:
                        self.logger.debug(f'Consuming from queue: {queue.name} ...')
                        self.failover_consume()
            except Exception as error:
                self.logger.error(f"Error while consuming from {queue_name}:\n{error}")
            finally:
                self._connection.release()
                self._connection = None
            time.sleep(self.settings.queue_timeout)
        self.logger.info('Consumer was stopped. Exiting.')

    def on_message_received_callback(self, body: bytes, message: Message) -> None:
        """
                Обертка для callback-метода обработчика

            body (Any) – Message body.
            delivery_mode (bool) – Set custom delivery mode. Defaults to delivery_mode.
            priority (int) – Message priority, 0 to broker configured max priority, where higher is better.
            content_type (str) – The messages content_type. If content_type is set, no serialization occurs
                                as it is assumed this is either a binary object, or you’ve done your own serialization.
                                Leave blank if using built-in serialization as our library properly sets content_type.
            content_encoding (str) – The character set in which this object is encoded.
                                    Use “binary” if sending in raw binary objects.
                                    Leave blank if using built-in serialization as our
                                    library properly sets content_encoding.
            properties (Dict) – Message properties.
            headers (Dict) – Message headers.
        """
        self.logger.debug(f"Got data from queue: {str(message.headers)}")
        try:
            self.callback(message.body, message.headers)
            if not self._auto_ack:
                message.ack()
        except Exception as error:
            self.logger.error(f'Callback event error while processing message: {message.headers}')
            self.on_error_callback(message.body, message.headers)

    def on_decode_error_callback(self, message: Message, exception: str) -> None:
        self.logger.error(f"Can't decode message ({str(message.headers)}) from queue: {exception}")

    def failover_consume(self) -> None:
        while self._run and not self.is_stopped():
            try:
                self._connection.drain_events(timeout=self.settings.queue_timeout)
            except socket.timeout:
                pass
            except Exception as error:
                self.logger.debug(error)
                break
