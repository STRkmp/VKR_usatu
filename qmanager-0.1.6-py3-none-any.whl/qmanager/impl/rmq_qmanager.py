from ..qmanager import QueueManager
from pydantic import BaseSettings
from typing import Callable, Optional
import pika
from pika.adapters.blocking_connection import BlockingConnection, BlockingChannel
from pika.amqp_object import Properties, Method
import logging
import uuid
import time


class RmqQueueManager(QueueManager):
    """ Pika Queue Manager """
    def __init__(self, settings: BaseSettings, callback_func: Callable = None, auto_ack: bool = True,
                 auto_declare: bool = True):
        QueueManager.__init__(self, settings, callback_func)
        self._auto_ack = auto_ack
        self._auto_declare = auto_declare
        logging.getLogger("pika").setLevel(logging.WARNING)
        self._credentials = pika.PlainCredentials(username=self.settings.username,
                                            password=self.settings.password)
        self._properties = pika.BasicProperties(content_type='application/octet-stream')
        self._connection = self.get_connection()
        self.init_queues()

    # Создаем множественные connection вместо channel, т.к. pika channels НЕ потокобезопасны
    def get_connection(self) -> Optional[BlockingConnection]:
        try:
            connection = pika.BlockingConnection(
                pika.ConnectionParameters(host=self.settings.host, port=self.settings.port,
                                          virtual_host=self.settings.virtual_host, credentials=self._credentials))
            return connection
        except Exception as error:
            self.logger.error(f"Can't get connection to RabbitMQ Server: {error}")
        return None

    def get_channel(self) -> Optional[BlockingChannel]:
        if self._connection is not None and self._connection.is_open:
            return self._connection.channel()
        return None

    def init_queues(self) -> None:
        if self._auto_declare:
            if self.settings.queue_in is not None:
                self._init_queue(self.settings.queue_in)
            if self.settings.queue_out is not None:
                self._init_queue(self.settings.queue_out)
            if self.settings.queue_in is not None:
                self._init_queue(self.settings.queue_err)

    def _init_queue(self, queue: str) -> bool:
        try:
            channel = self.get_channel()
            channel.queue_declare(passive=True, durable=True, queue=queue)
            channel.close()
        except:
            self.logger.info(f"Queue {queue} not found in vhost {self.settings.virtual_host}. Initializing...")
            try:
                channel = self.get_channel()
                channel.queue_declare(durable=True, queue=queue)
                channel.queue_bind(queue, self.settings.exchange, routing_key=queue)
                channel.close()
            except Exception as error:
                self.logger.error(f"Queues initialization error:\n{error}")
                return False
        return True

    def publish(self, data: bytes, queue_name: str = None, headers: dict = None) -> bool:
        if queue_name is None:
            queue_name = self.settings.queue_in
        if headers is None:
            headers = {'businessId': str(uuid.uuid4())}
        props = self._properties
        props.headers = headers
        self.logger.debug(f'Publishing message in {queue_name}. '
                          f'Header businessId: {props.headers.get("businessId")}')
        try:
            # Создаем множественные connection вместо channel, т.к. pika channels НЕ потокобезопасны
            connection = self.get_connection()
            channel = connection.channel()
            # channel.confirm_delivery(self.on_delivery_confirmation)
            channel.basic_publish(exchange=self.settings.exchange, routing_key=queue_name, body=data, properties=props)
            channel.close()
            return True
        except Exception as error:
            self.logger.error(f"Error while publishing message: {error}")
        return False

    # todo: обработка исключения: CONNECTION_FORCED - broker forced connection closure with reason 'shutdown'
    def consume(self, queue_name: str = None) -> None:
        if queue_name is None:
            queue_name = self.queue_in
        while self._run and not self.is_stopped():
            try:
                connection = self.get_connection()
                channel = connection.channel()
                channel.basic_qos(prefetch_count=1)     # todo: вынести в конфиг prefetch_count
                channel.basic_consume(queue=queue_name, on_message_callback=self.on_message_received,
                                      auto_ack=self._auto_ack)
                self.logger.debug(f'Consuming from queue: {queue_name} ...')
                channel.start_consuming()
            except Exception as error:
                self.logger.error(f"Error while consuming from {queue_name}:\n{error}")
            #    channel.stop_consuming()
            time.sleep(self.settings.queue_timeout)
        self.logger.info('Consumer was stopped. Exiting.')

    def on_message_received(self, channel: BlockingChannel, method: Method, properties: Properties, body: bytes) -> None:
        """
        Обертка для callback-метода обработчика

        on_message_callback(channel, method, properties, body)
             - channel: BlockingChannel
             - method: spec.Basic.Deliver
             - properties: spec.BasicProperties
             - body: bytes
        """
        self.logger.debug(f"Got data from queue: {properties.headers}")
        try:
            self.callback(body, properties.headers)
        except Exception as error:
            self.logger.error(f'Callback event error while processing message: {properties.headers}')
            self.on_error_callback(body, properties.headers)

    def on_delivery_confirmation(self, method_frame: Method) -> None:
        confirmation_type = method_frame.method.NAME.split('.')[1].lower()
        if confirmation_type == 'ack':
            self.logger.debug('message published')
        elif confirmation_type == 'nack':
            self.logger.debug('message not routed')